﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace WebAPITest
{
    public class TestMenuAlwaysOn
    {
        //Method to Keep the User Test Menu running unless user Exits
        public void KeepTestAlive()
        {
            TestHelperMethods apiTest = new TestHelperMethods();
            TestMenuOptions inputMenu = new TestMenuOptions();
            HttpClient callAPI = apiTest.NavigateBaseUrl();
            string userOption = inputMenu.Menu();
            if (userOption.ToLower() == "exit")
            {
                TestMenuOptions.ExitMenu();
            }
            else
            {
                string userInput = inputMenu.userInputStateName(userOption);
                Task newtask = apiTest.GetResponse(callAPI, userInput);
            }
            System.Threading.Thread.Sleep(4000);
            KeepTestAlive();
        }
    }

}
