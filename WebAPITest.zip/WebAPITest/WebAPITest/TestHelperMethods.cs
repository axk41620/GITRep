﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace WebAPITest
{
    class TestHelperMethods
    {
        //Method to hit API Base URL
        public string host_address = "http://services.groupkt.com//state//get//USA//";
        public HttpClient NavigateBaseUrl()
        {
            var client = new HttpClient();
            client.Timeout = new TimeSpan(0, 0, 10);
            client.BaseAddress = new Uri(host_address);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            return client;
        }

        //Method to get API response and display results
        public async Task GetResponse(HttpClient request, string userSearchInput)
        {
            try
            {
                using (request)
                {
                    HttpResponseMessage resMsg = await request.GetAsync(userSearchInput);
                    resMsg.EnsureSuccessStatusCode();
                    //Console.WriteLine(resMsg.EnsureSuccessStatusCode().ToString());
                    //Console.WriteLine(resMsg.Content.Headers.ContentType.MediaType.ToString());
                    var response = await resMsg.Content.ReadAsStringAsync();

                    //Code block for Invalid User Inputs resulting no response
                    if (resMsg.Content.Headers.ContentType.MediaType.Contains(@"text/html") && resMsg.IsSuccessStatusCode)
                    {
                        Console.WriteLine("\nInvalid User Input.\n");
                        Console.WriteLine("Try again with Valid input..................\n");
                    }
                    
                    //Code Block for Valid User Inputs
                    else if (resMsg.Content.Headers.ContentType.MediaType.Contains(@"application/json") && resMsg.IsSuccessStatusCode)
                    {
                        //code block for input= 'All' 
                        if (userSearchInput =="all")
                        {
                            var responseResult = JsonConvert.DeserializeObject<ResponseAllState.RootObject>(response);
                            Console.WriteLine();
                            Console.WriteLine("\n------------------Test response is as below :--------\n");
                            Console.WriteLine();
                            Console.WriteLine("Message: " + responseResult.restResponse.messages[0]);
                            for (int j = 0; j < responseResult.restResponse.result.Count; j++)
                            {
                                Console.WriteLine("Name: " + responseResult.restResponse.result[j].name);
                                Console.WriteLine("Capital: " + responseResult.restResponse.result[j].capital);
                                Console.WriteLine("Largest City: " + responseResult.restResponse.result[j].largest_city);
                                Console.WriteLine("----------------------------------------");
                            }
                            Console.WriteLine();
                            System.Threading.Thread.Sleep(1500);
                            Console.Write("Now redirecting to Main Menu.............\n");
                            System.Threading.Thread.Sleep(3000);
                        }

                        //code block for input=> State Name or Abbr 
                        else if (TestMenuOptions.StateAbbr().ContainsValue(userSearchInput))
                        {
                            Console.WriteLine(TestMenuOptions.StateAbbr().ContainsValue(userSearchInput));
                            var resultSingle = JsonConvert.DeserializeObject<ResponseSingleState.RootObject>(response);
                            //Console.WriteLine("-----------------------------------------------------------");
                            Console.WriteLine("\n------------------Test response is as below :--------\n");
                            Console.WriteLine("Message: " + resultSingle.restResponse.messages[0]);
                            Console.WriteLine("Capital: " + resultSingle.restResponse.result.capital);
                            Console.WriteLine("Largest City: " + resultSingle.restResponse.result.largest_city);
                            Console.WriteLine("-----------------------------------------------------------");
                            Console.WriteLine();
                            System.Threading.Thread.Sleep(1500);
                            Console.Write("Redirecting to Main Menu.............\n");
                            System.Threading.Thread.Sleep(3000);
                        }
                        else
                        {
                            var resultSingle = JsonConvert.DeserializeObject<ResponseSingleState.RootObject>(response);
                            //Console.WriteLine("-----------------------------------------------------------");
                            Console.WriteLine("\n------------------Test response is as below :--------\n");
                            Console.WriteLine("Message: " + resultSingle.restResponse.messages[0]);
                            System.Threading.Thread.Sleep(1500);
                            Console.WriteLine("-----------------------------------------------------------");
                            Console.Write("Redirecting to Main Menu.............\n");
                            System.Threading.Thread.Sleep(3000);
                        }
                    }
                    else
                    {
                        Console.WriteLine("-----------------------------------------------------------\n");
                        Console.WriteLine("Unknown or No Response, Test Failed, Need investigation........");
                        Console.WriteLine("\n-----------------------------------------------------------");
                        Console.Write("Redirecting to Main Menu.............\n");
                        System.Threading.Thread.Sleep(3000);
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
