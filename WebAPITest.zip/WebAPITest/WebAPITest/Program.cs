﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;

namespace WebAPITest
{
    class Program
    {
        static void Main(string[] args)
        {
            TestMenuAlwaysOn TestStateAPI = new TestMenuAlwaysOn();
            TestStateAPI.KeepTestAlive();
        }
    }
}
