﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPITest
{
    class TestMenuOptions
    {
        //Method for User Test input options
        public string Menu()
        {

            Console.WriteLine("\n***********************************************************************");
            Console.WriteLine("Welcome to API Test Wizard for Capital and Largest City of USA States.");
            Console.WriteLine("***********************************************************************\n");
            Console.WriteLine ("Menu A: Enter the Name or Abbraviation of a State in Uppercase letters");
            Console.WriteLine ("Menu B: Enter 'all' to get details of all the states");
            Console.WriteLine ("Menu C: Enter 'Exit' to leave the wizard");
            Console.WriteLine("\n-------------------------------------------------------------\n");
            Console.Write("Input your choice: ");
            return Console.ReadLine();
        }

        //Method to provide State Abbraviation as actual input when User enters State Name
        public string userInputStateName(string inputValue)
        {
            Hashtable dics = StateAbbr();
            foreach (DictionaryEntry kvp in dics)
            {
                if (kvp.Key.ToString().ToLower() == inputValue.ToLower())
                {
                    inputValue = kvp.Value.ToString();
                }
            }
            return inputValue;
        }

        //Method to Exit from API Test Menu
        public static void ExitMenu()
        {
            Console.WriteLine("-----------------------------------------------------------");
            Console.WriteLine("\nThanks for  visiting the API Test wizard.");
            Console.WriteLine("\nHave a good day.............................");
            System.Threading.Thread.Sleep(3000);
            System.Environment.Exit(0);
        }

        //List of States and their Abbr, used to fetch and pass Abbr when user enter State name
        public static Hashtable StateAbbr()
        {
            Hashtable dictionary = new Hashtable();
            dictionary.Add("Alabama", "AL");
            dictionary.Add("Alaska", "AK");
            dictionary.Add("Arizona", "AZ");
            dictionary.Add("Arkansas", "AR");
            dictionary.Add("California", "CA");
            dictionary.Add("Colorado", "CO");
            dictionary.Add("Connecticut", "CT");
            dictionary.Add("Delaware", "DE");
            dictionary.Add("Florida", "FL");
            dictionary.Add("Georgia", "GA");
            dictionary.Add("Hawaii", "HI");
            dictionary.Add("Idaho", "ID");
            dictionary.Add("Illinois", "IL");
            dictionary.Add("Indiana", "IN");
            dictionary.Add("Iowa", "IA");
            dictionary.Add("Kansas", "KS");
            dictionary.Add("Kentucky", "KY");
            dictionary.Add("Louisiana", "LA");
            dictionary.Add("Maine", "ME");
            dictionary.Add("Maryland", "MD");
            dictionary.Add("Massachusetts", "MA");
            dictionary.Add("Michigan", "MI");
            dictionary.Add("Minnesota", "MN");
            dictionary.Add("Mississippi", "MS");
            dictionary.Add("Missouri", "MO");
            dictionary.Add("Montana", "MT");
            dictionary.Add("Nebraska", "NE");
            dictionary.Add("Nevada", "NV");
            dictionary.Add("New Hampshire", "NH");
            dictionary.Add("New Jersey", "NJ");
            dictionary.Add("New Mexico", "NM");
            dictionary.Add("New York", "NY");
            dictionary.Add("North Carolina", "NC");
            dictionary.Add("North Dakota", "ND");
            dictionary.Add("Ohio", "OH");
            dictionary.Add("Oklahoma", "OK");
            dictionary.Add("Oregon", "OR");
            dictionary.Add("Pennsylvania", "PA");
            dictionary.Add("Rhode Island", "RI");
            dictionary.Add("South Carolina", "SC");
            dictionary.Add("South Dakota", "SD");
            dictionary.Add("Tennessee", "TN");
            dictionary.Add("Texas", "TX");
            dictionary.Add("Utah", "UT");
            dictionary.Add("Vermont", "VT");
            dictionary.Add("Virginia", "VA");
            dictionary.Add("Washington", "WA");
            dictionary.Add("Wisconsin", "WI");
            dictionary.Add("Wyoming", "WY");
            dictionary.Add("American Samoa", "AS");
            dictionary.Add("Guam", "GU");
            dictionary.Add("Northern Mariana Islands", "MP");
            dictionary.Add("Puerto Rico", "PR");
            dictionary.Add("U.S. Virgin Islands", "VI");
            return dictionary;
        }
    }
}